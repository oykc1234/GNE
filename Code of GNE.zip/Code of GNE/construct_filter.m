function g = construct_filter(Lambda_scaled, basis_type)
% construct_filter: Construct filter based on normalized eigenvalues and specified polynomial basis
% Input parameters:
%   Lambda_scaled - Normalized eigenvalues (column vector)
%   basis_type    - Polynomial basis type ('chebyshev', 'bessel', 'fibonacci', 'fourier', 'gegenbauer', 'hermite', 'jacobi', 'laguerre', 'legendre', 'lucas', or 'monomial')
% Output parameters:
%   g - Constructed filter (column vector)

    if strcmpi(basis_type, 'chebyshev')
        % Chebyshev polynomial definition
        T0 = ones(size(Lambda_scaled)) * 0.5; % T0(x) = 0.5
        T1 = Lambda_scaled;                  % T1(x) = x
        T2 = (2 * Lambda_scaled.^2);         % T2(x) = 2x^2
        T3 = (4 * Lambda_scaled.^3 - 2 * Lambda_scaled) + 1; % T3(x) = 4x^3 - 2x + 1

        % Construct filter
        %g = 0.001*T0 - 0.5 * T1 + 0.4 * T2 + 0.8*T3;
        %g =0.3*T0 - 0.3 * T1 + 0.25 * T2 + 0.5*T3;
        g = 0.5*T0 + 0.3 * T1 - 0.25 * T2 + 0.5*T3;
    elseif strcmpi(basis_type, 'bessel')
        % Bessel polynomial definition
        B0 = ones(size(Lambda_scaled));                   % y0(x) = 1
        B1 = 1 + Lambda_scaled;                           % y1(x) = 1 + x
        B2 = 1 + 3 * Lambda_scaled + Lambda_scaled.^2;    % y2(x) = 1 + 3x + x^2
        B3 = 1 + 6 * Lambda_scaled + 6 * Lambda_scaled.^2 + Lambda_scaled.^3; % y3(x) = 1 + 6x + 6x^2 + x^3

        % Construct filter
        g = 0.5 * B0 + 1.5 * B1 + 0.5 * B2 + 1.5 * B3;
        
    elseif strcmpi(basis_type, 'bernstein')
        % Bernstein polynomial definition
        n = 3; % Maximum order
        B0 = (1 - Lambda_scaled).^n; % B_n,0(x)
        B1 = n * Lambda_scaled .* (1 - Lambda_scaled).^(n-1); % B_n,1(x)
        B2 = n * (n-1) / 2 * Lambda_scaled.^2 .* (1 - Lambda_scaled).^(n-2); % B_n,2(x)
        B3 = Lambda_scaled.^n; % B_n,3(x)

        % Construct filter
        g = 0.7 * B0 - 1.0 * B1 + 0.5 * B2 + 2.5 * B3;
    elseif strcmpi(basis_type, 'fibonacci')
        % Fibonacci polynomial definition
        F0 = ones(size(Lambda_scaled));                       % F0(x) = 1
        F1 = Lambda_scaled;                                   % F1(x) = x
        F2 = Lambda_scaled.^2 + 2 * Lambda_scaled;            % F2(x) = x^2 + 2x
        F3 = Lambda_scaled.^3 + 3 * Lambda_scaled.^2 + Lambda_scaled; % F3(x) = x^3 + 3x^2 + x

        % Construct filter
        g = 0.5 * F0 + 1 * F1 + 0.5 * F2 + 1 * F3;

    elseif strcmpi(basis_type, 'fourier')
        % Fourier polynomial definition
        N = 3; % Select first N Fourier polynomials
        a0 = 1;
        ak = [0.5, 1, 0.8];
        bk = [0.3, 0.6, 0.9];

        % Initialize filter with constant term
        g = a0 / 2 * ones(size(Lambda_scaled));
        for k = 1:N
            g = g + ak(k) * cos(2 * pi * k * Lambda_scaled) + bk(k) * sin(2 * pi * k * Lambda_scaled);
        end

    elseif strcmpi(basis_type, 'gegenbauer')
        % Gegenbauer polynomial definition
        alpha = 1; % Parameter α
        G0 = ones(size(Lambda_scaled));
        G1 = 2 * alpha * Lambda_scaled;
        G2 = alpha * (2 * alpha + 1) * Lambda_scaled.^2 - alpha;
        G3 = (2 * alpha + 3) * (alpha + 1) * Lambda_scaled.^3 - 3 * (alpha + 1) * Lambda_scaled;

        % Construct filter
        g = 0.5 * G0 + 1 * G1 + 0.5 * G2 + 1 * G3;

    elseif strcmpi(basis_type, 'hermite')
        % Hermite polynomial definition
        H0 = ones(size(Lambda_scaled));
        H1 = 2 * Lambda_scaled;
        H2 = 4 * Lambda_scaled.^2 - 2;
        H3 = 8 * Lambda_scaled.^3 - 12 * Lambda_scaled;

        % Construct filter
        g = 0.5 * H0 + 1.0 * H1 + 0.5 * H2 + 1.5 * H3;

    elseif strcmpi(basis_type, 'jacobi')
        % Jacobi polynomial definition
        alpha = 0.5;
        beta = 0.5;
        J0 = ones(size(Lambda_scaled));
        J1 = 0.5 * (2 * (alpha + 1) + (alpha + beta + 2) * Lambda_scaled);
        J2 = 0.5 * (alpha + 1) * (alpha + 2) * Lambda_scaled.^2 + ...
             (alpha + 1) * (1 + beta) * Lambda_scaled + ...
             0.5 * (alpha + 1) * (beta - alpha);
        J3 = (1/6) * (alpha + 1) * (alpha + 2) * (alpha + 3) * Lambda_scaled.^3 + ...
             (1/2) * (alpha + 1) * (alpha + 2) * (1 + beta) * Lambda_scaled.^2 + ...
             (1/2) * (alpha + 1) * (2 + beta - alpha) * Lambda_scaled + ...
             (1/6) * (alpha + 1) * (beta - alpha);

        % Construct filter
        g = 0.5 * J0 + 1.0 * J1 + 0.5 * J2 + 1.5 * J3;

    elseif strcmpi(basis_type, 'laguerre')
        % Laguerre polynomial definition
        L0 = ones(size(Lambda_scaled));
        L1 = 1 - Lambda_scaled;
        L2 = 0.5 * (Lambda_scaled.^2 - 4 * Lambda_scaled + 2);
        L3 = (Lambda_scaled.^3 - 9 * Lambda_scaled.^2 + 18 * Lambda_scaled - 6) / 6;

        % Construct filter
        g = 0.5 * L0 + 1.0 * L1 + 0.5 * L2 + 1.5 * L3;

    elseif strcmpi(basis_type, 'legendre')
        % Legendre polynomial definition
        P0 = ones(size(Lambda_scaled));
        P1 = Lambda_scaled;
        P2 = 0.5 * (3 * Lambda_scaled.^2 - 1);
        P3 = 0.5 * (5 * Lambda_scaled.^3 - 3 * Lambda_scaled);

        % Construct filter
        g = 0.5 * P0 + 1.0 * P1 + 0.5 * P2 + 1.5 * P3;

    elseif strcmpi(basis_type, 'lucas')
        % Lucas polynomial definition
        L0 = 2 * ones(size(Lambda_scaled));   % L_0(x) = 2
        L1 = Lambda_scaled;                  % L_1(x) = x
        L2 = Lambda_scaled.^2 - 2;           % L_2(x) = x^2 - 2
        L3 = Lambda_scaled.^3 - 3 * Lambda_scaled; % L_3(x) = x^3 - 3x

        % Construct filter
        g = 0.5 * L0 + 1.0 * L1 + 0.5 * L2 + 1.5 * L3;

    elseif strcmpi(basis_type, 'monomial')
        % Monomial basis definition
        M0 = ones(size(Lambda_scaled));  % M_0(x) = 1
        M1 = Lambda_scaled;              % M_1(x) = x
        M2 = Lambda_scaled.^2;           % M_2(x) = x^2
        M3 = Lambda_scaled.^3;           % M_3(x) = x^3

        % Construct filter
        g = 0.5 * M0 + 1.0 * M1 + 0.5 * M2 + 1.5 * M3;

    else
        error('Unsupported basis type. Choose a valid polynomial basis.');
    end

    % Scale to [0, 2]
    g = 2*(g - min(g)) / (max(g) - min(g));

end
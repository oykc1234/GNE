close all; clear; clc;

% Benchmark function testing for Graph Neural Evolution (GNE) algorithm
% F1: Sphere - Unimodal, convex, symmetric function
% F2: Schwefel - Unimodal, non-convex function  
% F3: Schwefel 2.22 - Unimodal, non-differentiable function
% F4: Schwefel 2.26 - Multimodal, non-convex function
% F5: Rosenbrock - Unimodal, valley-shaped function
% F6: Quartic - Unimodal function with noise
% F7: Rastrigin - Highly multimodal function
% F8: Ackley - Multimodal function with nearly flat outer region
% F9: Levy - Multimodal, non-convex function

N = 30; % Population size
F = 'F9'; % Function F1 to F9 (select from benchmark functions)
T = 500; % Maximum number of iterations

% Available filter basis types for spectral graph neural network
basis_list = {'chebyshev', 'bessel', 'fibonacci', 'fourier', ...
              'gegenbauer', 'hermite', 'jacobi', 'laguerre', ...
              'legendre', 'lucas', 'monomial', 'bernstein'};
basis = basis_list{1}; % Select 'chebyshev' basis

% Load function details (bounds, dimension, objective function)
[lb, ub, D, fobj, Title] = Get_F(F); % ����Title���
lb = lb .* ones(1, D);
ub = ub .* ones(1, D);

% Run Graph Neural Evolution algorithm
[sBest, pBest, Conv] = GNE(N, T, lb, ub, D, fobj, basis);

% Plot search space
figure('Position', [454, 445, 694, 297]);
subplot(1, 2, 1);
func_plot(F);
title(Title, 'FontName', 'Times New Roman', 'FontWeight', 'bold')
xlabel('x_1', 'FontName', 'Times New Roman', 'FontWeight', 'bold');
ylabel('x_2', 'FontName', 'Times New Roman', 'FontWeight', 'bold');
zlabel([Title, '(x_1, x_2)'], 'FontName', 'Times New Roman', 'FontWeight', 'bold')
set(gca, 'FontName', 'Times New Roman', 'FontWeight', 'bold');

% Plot convergence curve
subplot(1, 2, 2);
semilogy(Conv, '-r', 'LineWidth', 2)
title(Title, 'FontName', 'Times New Roman', 'FontWeight', 'bold')
xlabel('Iteration #', 'FontName', 'Times New Roman', 'FontWeight', 'bold');
ylabel('Best Fitness Function', 'FontName', 'Times New Roman', 'FontWeight', 'bold');
axis tight
legend('GNE', 'FontName', 'Times New Roman', 'FontWeight', 'bold')
set(gca, 'FontName', 'Times New Roman', 'FontWeight', 'bold');

% Display optimal results
display(['The best solution obtained by GNE is: ', num2str(pBest)]);
display(['The best optimal value of the objective function found by GNE is: ', num2str(sBest)]);
function [X_new_pop, fitness_new, best_fitness, best_solution] = sample_function2(...
    X, X_new, fitness, f, best_fitness, best_solution, ub, lb, t, T, N, d)
% Sampling function: Generate next generation population
% Input:
%   X - Current population
%   X_new - New population after graph filtering
%   fitness - Current population fitness
%   f - Fitness function
%   best_fitness - Current best fitness
%   best_solution - Current best solution
%   ub, lb - Upper and lower bounds
%   t, T - Current iteration and total iterations
%   N - Population size
%   d - Problem dimension
% Output:
%   X_new_pop - New generation population
%   fitness_new - New generation population fitness
%   best_fitness - Updated best fitness
%   best_solution - Updated best solution

% Residual connection
X_new = 0.05 * X + 0.95 * X_new;

% Update population (boundary handling)
X_new = max(min(X_new, ub), lb); % Ensure new individuals are within solution space

% Calculate fitness of new population
new_fitness = zeros(N, 1);
for i = 1:N
    new_fitness(i) = f(X_new(i, :));
end

% Merge old and new populations
combined_population = [X; X_new]; % Merge populations
combined_fitness = [fitness; new_fitness]; % Merge fitness values

[current_best_fitness, idx] = min(combined_fitness);
if current_best_fitness < best_fitness
    best_fitness = current_best_fitness;
    best_solution = combined_population(idx, :);
end

% Set small standard deviation, generate around optimal solution (best for offset experiment)
std_X = 0.0005 * exp(-16 * (t - T/2) / (T/2));
X_new_pop = best_solution + std_X .* randn(N, d); % Generate Gaussian distribution population with optimal solution as mean
X_new_pop = max(min(X_new_pop, ub), lb); % Boundary handling

% Calculate fitness of new population
fitness_new = zeros(N, 1);
for i = 1:N
    fitness_new(i) = f(X_new_pop(i, :));
end
end
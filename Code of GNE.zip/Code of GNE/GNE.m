function [best_fitness, best_solution, Convergence_curve] = GNE(N, T, lb, ub, d, f, basis)
% GNE: Graph Neural Evolution 
% 
% This code is part of the paper "Learn from Global Correlations: Enhancing 
% Evolutionary Algorithm via Spectral GNN" accepted as a poster at The 
% Fortieth AAAI Conference on Artificial Intelligence (AAAI 2026)
%
% Authors: Kaichen Ouyang, Zong Ke, Shengwei Fu, Lingjie Liu, Puning Zhao, Dayu Hu
% Paper link: https://doi.org/10.48550/arXiv.2412.17629
%
% This code demonstrates a simple test demo of Graph Neural Evolution (GNE)
%
% Input:
%   N - Population size
%   T - Maximum number of iterations
%   lb - Lower bound of search space
%   ub - Upper bound of search space  
%   d - Dimension of the problem
%   f - Objective function
%   basis - Filter basis type
%
% Output:
%   best_fitness - Best fitness value found
%   best_solution - Best solution found
%   Convergence_curve - Convergence curve recording best fitness

% Initialize population with normal distribution
X = lb + (ub - lb) .* rand(N, d);

% Boundary handling to ensure X is within [lb, ub] range
X = max(min(X, ub), lb);

fitness = zeros(N, 1);            % Store fitness values
for i = 1:N
    fitness(i) = f(X(i, :));     % Calculate initial fitness
end

% Initialize convergence curve
Convergence_curve = zeros(1, T);

% Get initial best individual
[best_fitness, idx] = min(fitness);
best_solution = X(idx, :);

t = 1;

% Main loop
while t <= T
    fprintf('Iteration %d: Sampling function 1\n', t);
    
    % Sampling function 1: Identity transformation
    X = sample_function1(X, ub, lb);
    
    % Calculate fitness
    for i = 1:N
        fitness(i) = f(X(i, :));
    end
    
    % Construct adjacency matrix (encapsulated as subfunction)
    A = construct_adjacency_matrix(X);
    
    % Laplacian matrix
    D = diag(sum(A, 2));
    
    epsilon = 1e-10; % Prevent division by zero
    % Normalized Laplacian matrix
    D_inv_sqrt = diag(1 ./ sqrt(diag(D) + epsilon)); % Prevent division by zero
    L_norm = eye(N) - D_inv_sqrt * A * D_inv_sqrt; % Symmetric normalized Laplacian matrix
    
    % Spectral decomposition
    [U, Lambda] = eig(L_norm); % U: eigenvectors, Lambda: eigenvalues
    Lambda = diag(Lambda); % Extract eigenvalues
    
    % Eigenvalue normalization (encapsulated as subfunction)
    Lambda_scaled = normalize_eigenvalues(Lambda);
    
    % Call filter constructor
    g = construct_filter(Lambda_scaled, basis);
    
    % Spectral domain transformation
    X_hat = U' * X; % Map population to spectral domain
    
    % Filtering operation
    X_hat_filtered = g .* X_hat;
    
    % Inverse Fourier transform
    X_new = U * X_hat_filtered;
    
    fprintf('Iteration %d: Sampling function 2\n', t);
    
    % Generate next generation through sampling (encapsulated as subfunction)
    [X, fitness, best_fitness, best_solution] = sample_function2(...
        X, X_new, fitness, f, best_fitness, best_solution, ub, lb, t, T, N, d);
    
    % Update iteration count and convergence curve
    t = t + 1;
    Convergence_curve(t) = best_fitness;
    
    % Optional: Display current generation information
    % fprintf('Iteration %d/%d, Best Fitness: %.4f\n', t, T, best_fitness);
end
end
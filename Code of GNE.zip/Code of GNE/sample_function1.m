function X_new = sample_function1(X, ub, lb)
% Sampling function 1: Identity transformation
% Input:
%   X - Current population (N x d)
%   ub - Upper bound vector (1 x d)
%   lb - Lower bound vector (1 x d)
% Output:
%   X_new - New population after identity transformation (N x d)

% Identity transformation: Return original population without any changes
X_new = X;

% Boundary handling (theoretically not needed, but for safety)
X_new = max(min(X_new, ub), lb);

end
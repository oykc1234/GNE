function A = construct_adjacency_matrix(X)
% Construct adjacency matrix
% Input:
%   X - Population matrix (N x d)
% Output:
%   A - Adjacency matrix (N x N)

% Search space center
center = mean(X); % Information maximization

% Calculate differences between individuals and center
diff_X = X - center; % Difference vectors
diff_norm = sqrt(sum(diff_X.^2, 2)); % Norm of difference vectors
diff_norm(diff_norm == 0) = 1e-10; % Prevent division by zero
diff_X_norm = diff_X ./ diff_norm; % Normalized difference vectors

% Calculate cosine similarity matrix
cos_sim_matrix = exp(diff_X_norm * diff_X_norm');

% Construct adjacency matrix
A = cos_sim_matrix;

% Get maximum and minimum values
A_min = min(A(:)); % Minimum value of A
A_max = max(A(:)); % Maximum value of A

% Normalize A
A = (A - A_min + 1e-10) / (A_max - A_min + 1e-10);
end
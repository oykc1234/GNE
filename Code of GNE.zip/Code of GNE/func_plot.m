% Function plotting utility (optional - for visualization)
function func_plot(func_name)

[LB, UB, Dim, F_obj] = Get_F(func_name);

switch func_name 
    case 'F1' 
        x = -100:2:100; y = x; %[-100,100]
        
    case 'F2' 
        x = -10:0.2:10; y = x; %[-10,10]
        
    case 'F3' 
        x = -100:2:100; y = x; %[-100,100]
        
    case 'F4' 
        x = -500:10:500; y = x; %[-500,500]
        
    case 'F5' 
        x = -2:0.1:2; y = x; %[-2,2]
        
    case 'F6' 
        x = -1.28:0.05:1.28; y = x; %[-1.28,1.28]
        
    case 'F7' 
        x = -5.12:0.1:5.12; y = x; %[-5.12,5.12]
        
    case 'F8' 
        x = -32:0.5:32; y = x; %[-32,32]
        
    case 'F9' 
        x = -10:0.2:10; y = x; %[-10,10]
end

L = length(x);
f = [];

for i = 1:L
    for j = 1:L
        f(i, j) = F_obj([x(i), y(j)]);
    end
end

% Create surface plot
surfc(x, y, f, 'LineStyle', 'none');
title(func_name);
xlabel('x1');
ylabel('x2');
zlabel('f(x1,x2)');
colorbar;

end
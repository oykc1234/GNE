
function [LB,UB,Dim,F_obj, Title] = Get_F(F)
switch F
    case 'F1'
        F_obj = @F1;
        LB = -100;
        UB = 100;
        Dim = 30;
        Title = 'Sphere';
        
    case 'F2'
        F_obj = @F2;
        LB = -10;
        UB = 10;
        Dim = 30;
        Title = 'Schwefel';

    case 'F3'
        F_obj = @F3;
        LB = -100;
        UB = 100;
        Dim = 30; 
        Title = 'Schwefel 2.22';

    case 'F4'
        F_obj = @F4;
        LB = -100;
        UB = 100;
        Dim = 30; 
        Title = 'Schwefel 2.26';

    case 'F5'
        F_obj = @F5;
        LB = -30;
        UB = 30;
        Dim = 30; 
        Title = 'Rosenbrock';

    case 'F6'
        F_obj = @F6;
        LB = -1.28;
        UB = 1.28;
        Dim = 30;  
        Title = 'Quartic';

    case 'F7'
        F_obj = @F7;
        LB = -5.12;
        UB = 5.12;
        Dim = 30;   
        Title = 'Rastrigin';

    case 'F8'
        F_obj = @F8;
        LB = -32;
        UB = 32;
        Dim = 30;    
        Title = 'Ackley';

    case 'F9'
        F_obj = @F9;
        LB = -600;
        UB = 600;
        Dim = 30;    
        Title = 'Levy';

end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F1: Sphere Function

function o = F1(x)
    o = sum((x).^2);
end

% F2: Schwefel Function

function o = F2(x)
    o = sum(abs(x)) + prod(abs(x));
end

% F3: Schwefel 2.22 Function

function o = F3(x)
    dim = size(x, 2);
    o = 0;
    for i = 1:dim
        o = o + sum(x(1:i))^2;
    end
end

% F4: Schwefel 2.26 Function

function o = F4(x)
o=max(abs(x));
end

% F5: Rosenbrock Function

function o = F5(x)
dim=size(x,2);
o=sum(100*(x(2:dim)-(x(1:dim-1).^2)).^2+(x(1:dim-1)-1).^2);
end

% F6: Quartic Function

function o = F6(x)
dim=size(x,2);
o=sum([1:dim].*(x.^4))+rand;
end


% F7: Rastrigin Function

function o = F7(x)
dim=size(x,2);
o=sum(x.^2-10*cos(2*pi.*x))+10*dim;
end

% F8: Ackley Function

function o = F8(x)
dim=size(x,2);
o=-20*exp(-.2*sqrt(sum(x.^2)/dim))-exp(sum(cos(2*pi.*x))/dim)+20+exp(1);
end

% F9: Levy Function

function o = F9(x)
dim=size(x,2);
o=sum(x.^2)/4000-prod(cos(x./sqrt([1:dim])))+1;
end
function Lambda_scaled = normalize_eigenvalues(Lambda)
% 特征值归一化
% 输入:
%   Lambda - 特征值向量
% 输出:
%   Lambda_scaled - 归一化后的特征值向量 [0, 1]

% 对特征值进行非线性扩展并归一化到 [0, 1]
Lambda_expanded = exp(Lambda); % 使用指数放大特征值

% 防止所有的λ一样导致特征值一样都是1，归一化后分母等于0会报错
Lambda_scaled = (Lambda_expanded - min(Lambda_expanded) + 1e-10) / ...
                (max(Lambda_expanded) - min(Lambda_expanded) + 1e-10); % 归一化到 [0, 1]
end